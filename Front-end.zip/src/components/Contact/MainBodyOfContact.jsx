import Form from "./Form";
import MyGoogleMap from "./Map";

const MainBodyOfContact=()=>{
  return(
    <>  <Form/>
    <MyGoogleMap/></>
  
  )
}
export default  MainBodyOfContact;