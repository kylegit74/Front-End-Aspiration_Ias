import Heading from "../AdminComponent/AdminHomeComponent/Heading";
import MainBodyOfAdminHome from "../AdminComponent/AdminHomeComponent/MainBodyOfAdminHome";

function AdminHome()
{
    return (
        <div>
            <MainBodyOfAdminHome/>
        </div>
    )

}
export default AdminHome;