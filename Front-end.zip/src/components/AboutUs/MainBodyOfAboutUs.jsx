import OurMission from '../AboutUs/OurMission'
import OurVision from '../AboutUs/OurVision'
import WhoWeAre from '../AboutUs/WhoWeAre'
const MainBodyOfAboutUs=()=>{
    return(
        <div>
            <WhoWeAre/>
            <OurMission/>
            <OurVision/>
        </div>
    )

}
export default MainBodyOfAboutUs;
