import WhyChooseUsHeading from "./Heading";
import LongDescription from "./LongDescription";
import WhatMakesUsStandOut from "./WhatMakesusStandOut";


const WhyChoosUsMainBody=()=>{
    return (
  <div>
    <WhyChooseUsHeading/>
    <LongDescription/>
    <WhatMakesUsStandOut/>

  </div>
    )
}
export default WhyChoosUsMainBody;