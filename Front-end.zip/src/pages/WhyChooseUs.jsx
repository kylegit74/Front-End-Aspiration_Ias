import WhyChoosUsMainBody from '../../src/components/WhyChooseUs/MainBodyOfWhyChooseUs'
import MainLayout from "../layouts/MainLayout";

const WhyChoosUs = () => {
  return <MainLayout>
    <WhyChoosUsMainBody/>
  </MainLayout>;
};
export default WhyChoosUs;
