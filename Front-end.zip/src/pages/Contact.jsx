

import MainLayout from "../layouts/MainLayout";
import MainBodyOfContact from '../../src/components/Contact/MainBodyOfContact'

const ContactPage=()=>{
    return (
       <MainLayout>
        <MainBodyOfContact/>
       </MainLayout>
    )
}
export default ContactPage;