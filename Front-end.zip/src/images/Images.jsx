const Images = [
    {
    id: 1,
    url: 'images/banner.png',
    title: 'Image 1',
    },
    {
        id: 2,
        url: 'images/banner.png',
        title: 'Image 2',
    },
    {   
        id: 3,
        url: 'images/banner.png',
        title: 'Image 3',
    }
]


export default Images
